# 17/06/2020

- 08:00:00 <mensagem 1>
- 15:33:25 <mensagem 2>
- 19:22:03 <mensagem 3>

# 18/06/2020

- 08:00:00 <mensagem 4>
- 15:33:25 <mensagem 5>
- 19:22:03 <mensagem 6>

# 19/06/2020

- 08:00:00 <mensagem 7>
- 15:33:25 <mensagem 8>
- 19:22:03 <mensagem 9>