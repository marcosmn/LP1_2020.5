Programa do Supermercado para a 5º avaliação da materia de LP1-2020.5

Aluno: Marcos Martins Nóbrega

Alguns codigos usados na avaliação passada continuam nessa implementação
mesmo tendo sido atualizado para o uso de vector, então algumas variaveis
podem não estar sendo utilizadas